import React, { useEffect, useState } from 'react';
import { Modal, InputNumber, Slider, Button, Tabs, Typography, Divider, List, Input, message } from 'antd';
import { useSettingsContext } from '../context/subcontexts/SettingsContext'; // שימוש בקונטקסט
import './Settings.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTrash, faEdit } from '@fortawesome/free-solid-svg-icons';
import { useMediaQuery } from 'react-responsive';

const { Text } = Typography;

export default function Settings({ flag, setFlag }) {
  const isMobile = useMediaQuery({ query: '(max-width: 500px)' });
  const { settings, loading, fetchSettings, updateSettingValue, addCategory, updateCategory, deleteCategory } = useSettingsContext();

  const [newHourlyRate, setNewHourlyRate] = useState(0);
  const [newFixedExpensesRate, setNewFixedExpensesRate] = useState(0);
  const [newProfitRate, setNewProfitRate] = useState(0);
  const [categories, setCategories] = useState([]);
  const [categoryName, setCategoryName] = useState('');
  const [categoryDescription, setCategoryDescription] = useState('');
  const [editingCategory, setEditingCategory] = useState(null);

  useEffect(() => {
    if (flag) {
      fetchSettings(); // קריאה לפונקציה מהקונטקסט
    }
  }, [flag]);

  useEffect(() => {
    if (settings) {
      setNewHourlyRate(settings?.hourlyRate?.value || 0);
      setNewFixedExpensesRate(settings?.fixedExpensesRate?.value || 0);
      setNewProfitRate(settings?.profitRate?.value || 0);
      setCategories(settings?.materialCategories?.value || []);
    }
  }, [settings]);

  const saveSettings = async () => {
    if (newHourlyRate !== settings.hourlyRate.value) {
      await updateSettingValue('hourlyRate', newHourlyRate);
    }
    if (newFixedExpensesRate !== settings.fixedExpensesRate.value) {
      await updateSettingValue('fixedExpensesRate', newFixedExpensesRate);
    }
    if (newProfitRate !== settings.profitRate.value) {
      await updateSettingValue('profitRate', newProfitRate);
    }
    message.success('ההגדרות נשמרו בהצלחה');
  };

  const handleAddCategory = async () => {
    if (!categoryName.trim()) {
      message.error('יש להזין שם קטגוריה');
      return;
    }
    await addCategory({ name: categoryName, description: categoryDescription });
    setCategoryName('');
    setCategoryDescription('');
    message.success('קטגוריה נוספה בהצלחה');
  };

  const handleEditCategory = (category) => {
    setEditingCategory(category);
    setCategoryName(category.name);
    setCategoryDescription(category.description);
  };

  const handleUpdateCategory = async () => {
    if (!categoryName.trim()) {
      message.error('יש להזין שם קטגוריה');
      return;
    }
    const updatedCategory = { ...editingCategory, name: categoryName, description: categoryDescription };
    await updateCategory(editingCategory._id, updatedCategory);
    setEditingCategory(null);
    setCategoryName('');
    setCategoryDescription('');
    message.success('קטגוריה עודכנה בהצלחה');
  };

  const handleDeleteCategory = async (categoryId) => {
    await deleteCategory(categoryId);
    message.success('קטגוריה נמחקה בהצלחה');
  };

  return (
    <Modal
      open={flag}
      title="הגדרות תמחור וניהול קטגוריות"
      centered
      width={isMobile ? '100%' : 800}
      footer={null}
      onCancel={() => setFlag(false)}
    >
      <Tabs defaultActiveKey="1">
        {/* טאב תמחור */}
        <Tabs.TabPane tab="תמחור" key="1">
          <div>
            <div className="settings-item">
              <Text strong>עלות עבודה לשעה:</Text>
              <InputNumber
                min={0}
                value={newHourlyRate}
                onChange={setNewHourlyRate}
                style={{ width: '100%' }}
              />
            </div>
            <Divider />
            <div className="settings-item">
              <Text strong>אחוז השתתפות בהוצאות קבועות:</Text>
              <Slider
                min={0}
                max={100}
                value={newFixedExpensesRate}
                onChange={setNewFixedExpensesRate}
                tooltip={{ formatter: (value) => `${value}%` }}
              />
            </div>
            <Divider />
            <div className="settings-item">
              <Text strong>אחוז רווח:</Text>
              <Slider
                min={0}
                max={100}
                value={newProfitRate}
                onChange={setNewProfitRate}
                tooltip={{ formatter: (value) => `${value}%` }}
              />
            </div>
            <Button type="primary" onClick={saveSettings} block style={{ marginTop: '1em' }}>
              שמור שינויים
            </Button>
          </div>
        </Tabs.TabPane>

        {/* טאב ניהול קטגוריות */}
        <Tabs.TabPane tab="קטגוריות חומרי גלם" key="2">
          <div>
            <div>
              <Input
                placeholder="שם קטגוריה"
                value={categoryName}
                onChange={(e) => setCategoryName(e.target.value)}
              />
              <Input.TextArea
                placeholder="תיאור קטגוריה"
                value={categoryDescription}
                onChange={(e) => setCategoryDescription(e.target.value)}
                rows={3}
                style={{ marginTop: '0.5em' }}
              />
              {editingCategory ? (
                <Button type="primary" onClick={handleUpdateCategory} block style={{ marginTop: '1em' }}>
                  עדכן קטגוריה
                </Button>
              ) : (
                <Button type="primary" onClick={handleAddCategory} block style={{ marginTop: '1em' }}>
                  הוסף קטגוריה
                </Button>
              )}
            </div>
            <Divider />
            <List
              dataSource={categories}
              renderItem={(category) => (
                <List.Item
                  actions={[
                    <Button
                      type="text"
                      icon={<FontAwesomeIcon icon={faEdit} />}
                      onClick={() => handleEditCategory(category)}
                    />,
                    <Button
                      type="text"
                      icon={<FontAwesomeIcon icon={faTrash} />}
                      onClick={() => handleDeleteCategory(category._id)}
                    />,
                  ]}
                >
                  <List.Item.Meta title={category.name} description={category.description} />
                </List.Item>
              )}
            />
          </div>
        </Tabs.TabPane>
      </Tabs>
    </Modal>
  );
}
