import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { selectAverageHourlyRate } from './employeeHours';

const VAT_RATE = 1.17;

export const updateProductsWithRate = createAsyncThunk(
  'products/updateWithRate',
  async (_, { getState }) => {
    const state = getState();
    const averageHourlyRate = selectAverageHourlyRate(state); // שליפת שכר שעתי ממוצע
    const products = state.products; // מוצרים נוכחיים

    const updatedProducts = products.map(product => {
      return {
        ...product,
        sizes: product.sizes.map(size => {
          const baseIngredientCost = size.ingredients.reduce(
            (acc, ingredient) => acc + parseFloat(ingredient.processedCost || ingredient.actualCost || 0),
            0
          );

          const baseMixCost = size.mixes.reduce(
            (acc, mix) => acc + parseFloat(mix.actualCost || 0),
            0
          );

          const totalRawCost = baseIngredientCost + baseMixCost;
          const laborCost = (averageHourlyRate / 60) * size.preparationTime;
          const priceWithoutVAT = size.price / VAT_RATE;
          const totalCost = totalRawCost + laborCost;
          const profit = priceWithoutVAT - totalCost;
          const profitMargin = priceWithoutVAT > 0 ? ((profit / priceWithoutVAT) * 100).toFixed(2) : '0.00';

          return {
            ...size,
            totalRawCost: totalRawCost.toFixed(2),
            laborCost: laborCost.toFixed(2),
            profitMargin
          };
        })
      };
    });

    return updatedProducts;
  }
);

const productsSlice = createSlice({
  name: 'products',
  initialState: [],
  reducers: {
    setProductsState: (state, action) => {
      const { products, ingredientsState, mixesState, averageHourlyRate } = action.payload;
      return products;
    },
    addOrUpdateProductState: (state, action) => {
      const { newProduct, ingredientsState, mixesState, averageHourlyRate } = action.payload;
      const updatedProduct = newProduct;

      const existingIndex = state.findIndex((product) => product._id === newProduct._id);
      if (existingIndex !== -1) {
        state[existingIndex] = updatedProduct;
      } else {
        state.unshift(updatedProduct);
      }
    },
    updateProductState: (state, action) => {
      const { updatedProduct, ingredientsState, mixesState, averageHourlyRate } = action.payload;
      const updatedProductState = updatedProduct;
      return state.map((product) =>
        product._id === updatedProduct._id ? updatedProductState : product
      );
    },
    deleteProductState: (state, action) => {
      const deletedProductId = action.payload._id;
      return state.filter((product) => product._id !== deletedProductId);
    },
  },
  extraReducers: (builder) => {
    builder.addCase(updateProductsWithRate.fulfilled, (state, action) => {
      return action.payload;
    });
  },
});

export const { setProductsState, addOrUpdateProductState, updateProductState, deleteProductState } = productsSlice.actions;
export default productsSlice.reducer;